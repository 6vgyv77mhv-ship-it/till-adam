# Adams födelsedagsbrev ❤️

Lägg `index.html` och `Böyle Sever.mp3` i samma GitHub-repository.

## GitHub Pages
1. Skapa ett repository.
2. Ladda upp de två filerna.
3. Öppna **Settings → Pages**.
4. Välj **Deploy from a branch**, `main` och `/ (root)`.
5. Spara och öppna länken GitHub ger dig.

Musiken startar när Adam trycker på kuvertet. Detta är viktigt för mobiltelefoner eftersom iOS/Android ofta blockerar autoplay innan användaren har tryckt någonstans.
